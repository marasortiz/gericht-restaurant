import React from 'react';

import './Footer.css';

const Footer = () => (
  <div>
    Footer
  </div>
);

export default Footer;
